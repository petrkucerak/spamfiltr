STANDARD_EMAIL_ADDRESS = "standardEmailAddress"
STANDARD_NUMBER = "standardPureNumber"
STANDARD_PHONE_NUMBER = "standardPhoneNumber"
STANDARD_URL = "standardUrlString"
STANDARD_IP_ADDRESS = "standardIpAddress"
STANDARD_PRICE = "standardPriceString"
STANDARD_REPEAT_SEQUENCE = "notableRepeatingChars"

SPAM_TAG = 'SPAM'
HAM_TAG = 'OK'
