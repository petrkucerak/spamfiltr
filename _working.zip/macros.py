class CustomMacros:
    standard_email_address = "standardEmailAddress"
    standard_pure_number = "standardPureNumber"
    standard_phone_number = "standardPhoneNumber"
    standard_url = "standardUrlString"
    standard_ip_address = "standardIpAddress"
    standard_price_string = "standardPriceString"
    notable_repeating_sequence = "notableRepeatingChars"
