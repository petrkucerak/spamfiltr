import numpy as np

TYPE_SPLIT = 0.5


class LogisticRegression:
    def _sigmoid(self, t):
        return 1/(1 + np.exp(-t))

    def _derive_weights(self, samples, X, predicted, y):
        return (1/samples)*np.dot(X.transpose(), predicted-y)

    def _derive_bias(self, samples, predicted, y):
        return (1/samples)*np.sum(predicted-y)

    def __init__(self, learning_rate=0.0001, iterations=1000, bias=0, weights=None):
        self.learning_rate = learning_rate
        self.iterations = iterations
        self.bias = bias
        self.weights = weights

    def fit(self, X, y):
        samples, features = X.shape
        if self.weights == None:
            self.weights = np.zeros(features)
        for _ in range(self. iterations):
            linear_model = np.dot(X, self.weights)+self.bias
            predicted = self._sigmoid(linear_model)

            self.weights -= self.learning_rate * \
                self._derive_weights(samples, X, predicted, y)
            self.bias -= self.learning_rate * \
                self._derive_bias(samples,  predicted, y)

    def predict(self, X):
        linear_model = np.dot(X, self.weights)+self.bias
        predicted = self._sigmoid(linear_model)

        predicted_type = [1 if x > TYPE_SPLIT else 0 for x in predicted]
        return predicted, predicted_type


if __name__ == "__main__":
    from sklearn import datasets
    from sklearn.model_selection import train_test_split

    bc = datasets.load_breast_cancer()
    X, y = bc.data, bc.target
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=1234)

    reg = LogisticRegression()
    reg.fit(X_train, y_train)
    predictions = reg.predict(X_test)
    print(
        f'accuracy: {np.sum(y_test == predictions)/len(y_test)}, bias: {reg.bias}, weights: {reg.weights}')
